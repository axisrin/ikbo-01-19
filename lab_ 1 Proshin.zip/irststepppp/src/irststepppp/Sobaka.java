/*  
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package irststepppp;

/**
 *
 * @axi
 */
public class Sobaka {
    private double weight;
    private String name;
    
    public Sobaka ()
    {
        name = "Bobik";
        weight = 25.0;
    }
    
    public Sobaka ( String nameSobaka , double weightSobaka )
    {
        name = nameSobaka;
        weight = weightSobaka;
    }
    
    public void getStats ()
    {
        
        System.out.println(name);
        System.out.println(weight);
        
    }
            
}
