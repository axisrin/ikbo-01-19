/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

// 01.09.2020
package irststepppp;

/**
 *
 * @author student
 */
public class Irststepppp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Sobaka dog1 = new Sobaka();
        Sobaka dog2 = new Sobaka("Sharik",35.5);
        dog1.getStats();
        dog2.getStats();
    }
    
}
